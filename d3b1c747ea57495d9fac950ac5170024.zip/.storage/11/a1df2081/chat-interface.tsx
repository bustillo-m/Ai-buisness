import { useState, useRef, useEffect } from "react";
import { useChat } from "@/lib/chat-context";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { PlusCircle, Send, Trash, AlertCircle, Loader2 } from "lucide-react";
import { Message } from "@/lib/types";
import { ChatSidebar } from "./chat-sidebar";

export function ChatInterface() {
  const { messages, isLoading, error, sendMessage, clearMessages } = useChat();
  const { apiKey } = useAuth();
  const [input, setInput] = useState("");
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading) {
      sendMessage(input.trim());
      setInput("");
    }
  };

  const renderMessageContent = (message: Message) => {
    return message.content.split("\n").map((line, i) => (
      <p key={i} className={i > 0 ? "mt-2" : ""}>
        {line}
      </p>
    ));
  };

  return (
    <div className="flex h-[calc(100vh-64px-56px)]">
      {/* Sidebar móvil */}
      <div className={`fixed inset-0 z-40 flex md:hidden transition-opacity duration-200 ${
        isMobileSidebarOpen ? "opacity-100" : "opacity-0 pointer-events-none"
      }`}>
        <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" 
             onClick={() => setIsMobileSidebarOpen(false)} />
        <div className={`relative flex w-full max-w-xs flex-1 flex-col bg-background transition-transform duration-200 ${
          isMobileSidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}>
          <ChatSidebar onSelectSession={() => setIsMobileSidebarOpen(false)} />
        </div>
      </div>

      {/* Sidebar escritorio */}
      <div className="hidden md:flex w-64 flex-shrink-0 border-r">
        <ChatSidebar />
      </div>

      {/* Interface principal del chat */}
      <div className="flex flex-col w-full">
        {/* Mensajes */}
        <div className="flex-1 overflow-hidden">
          <ScrollArea className="h-full p-4">
            {!apiKey && (
              <Alert className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Necesitas configurar tu API Key de OpenAI para usar el chat. Dirígete a la página de Configuración.
                </AlertDescription>
              </Alert>
            )}
            
            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full py-8 text-center">
                <h3 className="text-2xl font-semibold mb-2">Bienvenido a Autobisnes Chat</h3>
                <p className="text-muted-foreground mb-6 max-w-md">
                  Tu asistente IA profesional para empresas. Pregunta cualquier cosa relacionada con tu negocio.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map((message) => (
                  <Card
                    key={message.id}
                    className={`p-4 ${
                      message.role === "user"
                        ? "bg-primary/10 ml-12"
                        : message.role === "system"
                        ? "bg-secondary/20"
                        : "bg-secondary/10 mr-12"
                    }`}
                  >
                    <div className="flex items-start gap-2">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                        message.role === "user"
                          ? "bg-primary text-primary-foreground"
                          : "bg-blue-600 text-white"
                      }`}>
                        {message.role === "user" ? "U" : "A"}
                      </div>
                      <div className="flex-1">
                        <div className="font-medium">
                          {message.role === "user" ? "Tú" : message.role === "system" ? "Sistema" : "Autobisnes"}
                        </div>
                        <div className="mt-1">{renderMessageContent(message)}</div>
                      </div>
                    </div>
                  </Card>
                ))}
                <div ref={messagesEndRef} />
              </div>
            )}
          </ScrollArea>
        </div>

        {/* Formulario de entrada */}
        <div className="border-t p-4">
          <form onSubmit={handleSubmit} className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              size="icon"
              className="flex-shrink-0 md:hidden"
              onClick={() => setIsMobileSidebarOpen(true)}
            >
              <PlusCircle className="h-5 w-5" />
              <span className="sr-only">Abrir sidebar</span>
            </Button>
            <Button
              type="button"
              variant="outline"
              size="icon"
              className="flex-shrink-0"
              onClick={clearMessages}
              title="Limpiar conversación"
            >
              <Trash className="h-5 w-5" />
              <span className="sr-only">Limpiar conversación</span>
            </Button>
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Escribe tu mensaje..."
              className="flex-1 resize-none"
              rows={1}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
            />
            <Button
              type="submit"
              className="flex-shrink-0"
              disabled={isLoading || !input.trim()}
            >
              {isLoading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <Send className="h-5 w-5" />
              )}
              <span className="sr-only">Enviar</span>
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}