import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-[calc(100vh-64px-56px)]">
      {/* Hero Section */}
      <section className="py-12 md:py-24 lg:py-32 bg-gradient-to-br from-white to-blue-50 dark:from-gray-900 dark:to-gray-800">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                  Autobisnes
                </h1>
                <p className="text-xl text-blue-600 font-semibold">
                  IA profesional para empresas
                </p>
                <p className="max-w-[600px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Una solución inteligente para optimizar procesos, obtener insights valiosos y hacer crecer tu negocio.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link to="/chat">
                  <Button size="lg" className="px-8">
                    Probar Ahora
                  </Button>
                </Link>
                <Link to="/precios">
                  <Button size="lg" variant="outline" className="px-8">
                    Ver Planes
                  </Button>
                </Link>
              </div>
            </div>
            <div className="mx-auto lg:ml-auto flex justify-center">
              <div className="relative w-full max-w-[500px] aspect-square rounded-xl overflow-hidden shadow-xl border bg-blue-50 dark:bg-blue-900/20">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-blue-600 animate-pulse"></div>
                  <div className="absolute w-32 h-32 rounded-full border-4 border-blue-300 animate-ping"></div>
                  <div className="absolute w-48 h-48 rounded-full border-2 border-blue-200"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 md:py-24 bg-white dark:bg-gray-950">
        <div className="container px-4 md:px-6">
          <div className="text-center space-y-3 mb-12">
            <h2 className="text-3xl font-bold">Capacidades de Autobisnes</h2>
            <p className="text-xl text-muted-foreground mx-auto max-w-[800px]">
              Una IA diseñada específicamente para potenciar tu negocio
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center p-6 bg-background rounded-lg shadow-sm border">
              <div className="rounded-full bg-primary/10 p-4 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-primary">
                  <path d="M14 9V4a2 2 0 1 0-4 0v5"></path><path d="M18.42 4h1a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-1"></path>
                  <path d="M4.58 4h-1a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h1"></path><path d="M4.58 13v3c0 1.1.9 2 2 2h10a2 2 0 0 0 2-2v-3"></path>
                  <path d="M9 16V9"></path><path d="M15 16V9"></path>
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Asistencia inteligente</h3>
              <p className="text-muted-foreground">Respuestas precisas a consultas complejas sobre gestión, marketing y finanzas empresariales.</p>
            </div>
            <div className="flex flex-col items-center text-center p-6 bg-background rounded-lg shadow-sm border">
              <div className="rounded-full bg-primary/10 p-4 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-primary">
                  <path d="M2 16V4a2 2 0 0 1 2-2h11"></path><path d="M5 14H4a2 2 0 1 0 0 4h1"></path>
                  <path d="M22 18H11a2 2 0 1 0 0 4h11a2 2 0 0 0 2-2v-1a2 2 0 0 0-2-2Z"></path><path d="M15 12V7a2 2 0 0 0-2-2h-1"></path>
                  <path d="M8 12v-2"></path>
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Generación de contenido</h3>
              <p className="text-muted-foreground">Creación rápida de documentos, informes, emails y propuestas profesionales en segundos.</p>
            </div>
            <div className="flex flex-col items-center text-center p-6 bg-background rounded-lg shadow-sm border">
              <div className="rounded-full bg-primary/10 p-4 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-primary">
                  <path d="M3 5v14"></path><path d="m20 10-9 4-9-4"></path><path d="m20 18-9 4-9-4"></path><path d="M20 6 11 2 2 6"></path>
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Análisis de datos</h3>
              <p className="text-muted-foreground">Interpretación de datos e identificación de patrones para tomar decisiones más informadas.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-24 bg-blue-600">
        <div className="container px-4 md:px-6 text-center">
          <div className="max-w-[800px] mx-auto space-y-4">
            <h2 className="text-3xl font-bold text-white">Potencia tu empresa con Autobisnes</h2>
            <p className="text-xl text-blue-100">Regístrate hoy y obtén acceso a todas las capacidades de nuestra IA profesional</p>
            <div className="flex flex-col sm:flex-row justify-center gap-4 pt-4">
              <Link to="/register">
                <Button size="lg" variant="secondary" className="px-8">
                  Comenzar Gratis
                </Button>
              </Link>
              <Link to="/chat">
                <Button size="lg" variant="outline" className="px-8 bg-transparent text-white hover:bg-white hover:text-blue-600">
                  Probar Demo
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}