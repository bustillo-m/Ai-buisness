import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useAuth } from "./auth-context";
import { ChatSession, Message } from "./types";

interface ChatContextType {
  sessions: ChatSession[];
  currentSession: ChatSession | null;
  isLoading: boolean;
  createSession: () => ChatSession;
  selectSession: (sessionId: string) => void;
  deleteSession: (sessionId: string) => void;
  sendMessage: (content: string) => Promise<void>;
  clearMessages: () => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

const STORAGE_KEY = "autobisnes_chat_sessions";

export function ChatProvider({ children }: { children: ReactNode }) {
  const { user, apiKey, status } = useAuth();
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSession, setCurrentSession] = useState<ChatSession | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Cargar sesiones de chat desde localStorage
  useEffect(() => {
    if (status === "authenticated") {
      try {
        const storedSessions = localStorage.getItem(`${STORAGE_KEY}_${user?.id}`);
        if (storedSessions) {
          const parsedSessions: ChatSession[] = JSON.parse(storedSessions);
          setSessions(parsedSessions);
          
          // Establecer la sesión actual (última utilizada o la primera)
          const lastSessionId = localStorage.getItem(`${STORAGE_KEY}_current_${user?.id}`);
          const sessionToSelect = lastSessionId 
            ? parsedSessions.find(s => s.id === lastSessionId) 
            : parsedSessions[0];
            
          if (sessionToSelect) {
            setCurrentSession(sessionToSelect);
          } else if (parsedSessions.length === 0) {
            // Crear una nueva sesión si no hay ninguna
            const newSession = createNewSession();
            setSessions([newSession]);
            setCurrentSession(newSession);
            saveSessions([newSession], newSession.id);
          }
        } else {
          // No hay sesiones, crear una nueva
          const newSession = createNewSession();
          setSessions([newSession]);
          setCurrentSession(newSession);
          saveSessions([newSession], newSession.id);
        }
      } catch (error) {
        console.error("Error loading chat sessions:", error);
      }
    }
  }, [user, status]);

  // Guardar sesiones en localStorage
  const saveSessions = (sessionsList: ChatSession[], currentId: string | null = null) => {
    if (user) {
      localStorage.setItem(`${STORAGE_KEY}_${user.id}`, JSON.stringify(sessionsList));
      if (currentId) {
        localStorage.setItem(`${STORAGE_KEY}_current_${user.id}`, currentId);
      }
    }
  };

  // Crear una nueva sesión
  const createNewSession = (): ChatSession => {
    const now = Date.now();
    return {
      id: `session_${now}`,
      title: `Nueva conversación`,
      messages: [],
      createdAt: now,
      updatedAt: now,
    };
  };

  // Crear una nueva sesión y seleccionarla
  const createSession = (): ChatSession => {
    const newSession = createNewSession();
    const updatedSessions = [...sessions, newSession];
    setSessions(updatedSessions);
    setCurrentSession(newSession);
    saveSessions(updatedSessions, newSession.id);
    return newSession;
  };

  // Seleccionar una sesión existente
  const selectSession = (sessionId: string) => {
    const session = sessions.find((s) => s.id === sessionId);
    if (session) {
      setCurrentSession(session);
      localStorage.setItem(`${STORAGE_KEY}_current_${user?.id}`, sessionId);
    }
  };

  // Eliminar una sesión
  const deleteSession = (sessionId: string) => {
    const updatedSessions = sessions.filter((s) => s.id !== sessionId);
    setSessions(updatedSessions);
    
    if (currentSession?.id === sessionId) {
      const newCurrentSession = updatedSessions.length > 0 ? updatedSessions[0] : null;
      setCurrentSession(newCurrentSession);
      saveSessions(updatedSessions, newCurrentSession?.id || null);
    } else {
      saveSessions(updatedSessions, currentSession?.id || null);
    }
  };

  // Enviar un mensaje a la IA
  const sendMessage = async (content: string): Promise<void> => {
    if (!currentSession || !apiKey) return;

    try {
      setIsLoading(true);

      // Crear mensaje del usuario
      const userMessage: Message = {
        id: `msg_${Date.now()}`,
        content,
        role: "user",
        timestamp: Date.now(),
      };

      // Actualizar la sesión con el mensaje del usuario
      const sessionWithUserMsg = {
        ...currentSession,
        messages: [...currentSession.messages, userMessage],
        updatedAt: Date.now(),
      };
      
      // Si el título es genérico y este es el primer mensaje, generar un título basado en el contenido
      let updatedTitle = sessionWithUserMsg.title;
      if (sessionWithUserMsg.title === "Nueva conversación" && sessionWithUserMsg.messages.length === 1) {
        updatedTitle = content.length > 30 ? `${content.substring(0, 30)}...` : content;
        sessionWithUserMsg.title = updatedTitle;
      }

      // Actualizar la sesión actual y las sesiones
      setCurrentSession(sessionWithUserMsg);
      const updatedSessions = sessions.map(s => 
        s.id === currentSession.id ? sessionWithUserMsg : s
      );
      setSessions(updatedSessions);
      saveSessions(updatedSessions, sessionWithUserMsg.id);

      // En una implementación real, aquí se haría una llamada a la API de OpenAI
      // Para esta demo, simulamos una respuesta

      // Simular un tiempo de respuesta
      await new Promise((resolve) => setTimeout(resolve, 1500));

      // Crear una respuesta simulada
      const assistantMessage: Message = {
        id: `msg_${Date.now()}`,
        content: generateMockResponse(content),
        role: "assistant",
        timestamp: Date.now(),
      };

      // Actualizar la sesión con la respuesta
      const sessionWithBothMsgs = {
        ...sessionWithUserMsg,
        messages: [...sessionWithUserMsg.messages, assistantMessage],
        updatedAt: Date.now(),
      };

      // Actualizar la sesión actual y las sesiones
      setCurrentSession(sessionWithBothMsgs);
      const finalUpdatedSessions = updatedSessions.map(s => 
        s.id === currentSession.id ? sessionWithBothMsgs : s
      );
      setSessions(finalUpdatedSessions);
      saveSessions(finalUpdatedSessions, sessionWithBothMsgs.id);

    } catch (error) {
      console.error("Error sending message:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Limpiar todos los mensajes de la sesión actual
  const clearMessages = () => {
    if (!currentSession) return;

    const clearedSession = {
      ...currentSession,
      messages: [],
      updatedAt: Date.now(),
    };

    setCurrentSession(clearedSession);
    const updatedSessions = sessions.map(s => 
      s.id === currentSession.id ? clearedSession : s
    );
    setSessions(updatedSessions);
    saveSessions(updatedSessions, clearedSession.id);
  };

  // Función para generar respuestas simuladas
  const generateMockResponse = (query: string): string => {
    if (query.toLowerCase().includes("hola") || query.toLowerCase().includes("buenos días") || query.toLowerCase().includes("buenas")) {
      return "¡Hola! Soy el asistente IA de Autobisnes. ¿En qué puedo ayudarte hoy?";
    } else if (query.toLowerCase().includes("ayuda") || query.toLowerCase().includes("cómo funciona")) {
      return "Estoy aquí para ayudarte con consultas sobre negocios, marketing, análisis de datos y más. Solo tienes que escribir tu pregunta y te responderé con la información más relevante. ¿Sobre qué tema quieres que te asesore?";
    } else if (query.toLowerCase().includes("precio") || query.toLowerCase().includes("plan") || query.toLowerCase().includes("costo") || query.toLowerCase().includes("suscripción")) {
      return "Autobisnes ofrece varios planes: un plan básico gratuito con funciones limitadas, un plan Profesional por 29€ al mes con conversaciones ilimitadas, y un plan Empresarial por 99€ al mes con características avanzadas para equipos. Puedes ver todos los detalles en la sección de Precios.";
    } else if (query.toLowerCase().includes("negocio") || query.toLowerCase().includes("empresa") || query.toLowerCase().includes("emprender")) {
      return "Para iniciar o mejorar un negocio, es importante identificar un problema claro, conocer a tu cliente objetivo, desarrollar una propuesta de valor única, crear un plan de negocios sólido y definir una estrategia de marketing efectiva. ¿Hay algún aspecto específico sobre el que necesitas más información?";
    } else if (query.toLowerCase().includes("marketing") || query.toLowerCase().includes("publicidad") || query.toLowerCase().includes("promoción")) {
      return "Las estrategias de marketing más efectivas actualmente incluyen el marketing de contenidos, SEO, redes sociales, email marketing y marketing de influencers. Es importante definir claramente tu público objetivo y adaptar tus mensajes a sus necesidades específicas. ¿Necesitas ayuda con alguna estrategia en particular?";
    } else {
      return "Gracias por tu consulta. Como asistente IA de Autobisnes, puedo ayudarte con estrategias de negocio, marketing, análisis financiero, tendencias de mercado y más. Para darte una respuesta más precisa, ¿podrías proporcionar más detalles sobre lo que estás buscando?";
    }
  };

  // Valor del contexto
  const value = {
    sessions,
    currentSession,
    isLoading,
    createSession,
    selectSession,
    deleteSession,
    sendMessage,
    clearMessages,
  };

  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
}

export const useChat = (): ChatContextType => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error("useChat debe ser utilizado dentro de un ChatProvider");
  }
  return context;
};