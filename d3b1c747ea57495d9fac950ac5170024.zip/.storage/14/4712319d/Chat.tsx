import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/auth-context";
import { ChatInterface } from "@/components/chat/chat-interface";

export default function ChatPage() {
  const { status, apiKey } = useAuth();
  const navigate = useNavigate();

  // Si el usuario no está autenticado, redirigir al login
  useEffect(() => {
    if (status === "unauthenticated") {
      navigate("/login");
    }
  }, [status, navigate]);

  // Si está cargando, mostrar un indicador de carga
  if (status === "loading") {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-64px-56px)]">
        <div className="text-center">
          <div className="w-12 h-12 rounded-full border-4 border-blue-600 border-t-transparent animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Cargando...</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <ChatInterface />
    </div>
  );
}