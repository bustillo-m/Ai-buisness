import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { User, AuthStatus } from "./types";

interface AuthContextType {
  user: User | null;
  status: AuthStatus;
  apiKey: string | null;
  setApiKey: (key: string) => void;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string) => Promise<void>;
  signOut: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [status, setStatus] = useState<AuthStatus>('loading');
  const [apiKey, setApiKey] = useState<string | null>(null);
  
  useEffect(() => {
    // Comprobar si hay un usuario en localStorage
    const storedUser = localStorage.getItem('autobisnes_user');
    const storedApiKey = localStorage.getItem('autobisnes_api_key');
    
    if (storedUser) {
      setUser(JSON.parse(storedUser));
      setStatus('authenticated');
    } else {
      setStatus('unauthenticated');
    }
    
    if (storedApiKey) {
      setApiKey(storedApiKey);
    }
  }, []);

  const signIn = async (email: string, password: string) => {
    // Simulación de autenticación
    // En una implementación real, esto llamaría a un endpoint de autenticación
    const mockUser: User = {
      id: `user_${Math.random().toString(36).substr(2, 9)}`,
      email
    };
    
    setUser(mockUser);
    setStatus('authenticated');
    localStorage.setItem('autobisnes_user', JSON.stringify(mockUser));
  };

  const signUp = async (email: string, password: string) => {
    // Simulación de registro
    const mockUser: User = {
      id: `user_${Math.random().toString(36).substr(2, 9)}`,
      email
    };
    
    setUser(mockUser);
    setStatus('authenticated');
    localStorage.setItem('autobisnes_user', JSON.stringify(mockUser));
  };

  const signOut = () => {
    setUser(null);
    setStatus('unauthenticated');
    localStorage.removeItem('autobisnes_user');
    // Nota: No eliminamos la API key al cerrar sesión para mayor comodidad
  };

  const updateApiKey = (key: string) => {
    setApiKey(key);
    localStorage.setItem('autobisnes_api_key', key);
    if (user) {
      const updatedUser = { ...user, apiKey: key };
      setUser(updatedUser);
      localStorage.setItem('autobisnes_user', JSON.stringify(updatedUser));
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        status,
        apiKey,
        setApiKey: updateApiKey,
        signIn,
        signUp,
        signOut
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth debe ser usado dentro de un AuthProvider");
  }
  return context;
}