import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { User, AuthStatus } from "./types";

interface AuthContextType {
  user: User | null;
  status: AuthStatus;
  apiKey: string | null;
  signIn: (email: string, password: string) => Promise<User>;
  signUp: (email: string, password: string, name?: string) => Promise<User>;
  signOut: () => Promise<void>;
  updateApiKey: (apiKey: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [status, setStatus] = useState<AuthStatus>("loading");
  const [apiKey, setApiKey] = useState<string | null>(null);

  // Cargar datos de usuario y API key del localStorage al inicio
  useEffect(() => {
    const loadUserData = () => {
      try {
        const storedUser = localStorage.getItem("autobisnes_user");
        const storedApiKey = localStorage.getItem("autobisnes_api_key");
        
        if (storedUser) {
          setUser(JSON.parse(storedUser));
          setStatus("authenticated");
        } else {
          setStatus("unauthenticated");
        }
        
        if (storedApiKey) {
          setApiKey(storedApiKey);
        }
      } catch (error) {
        console.error("Error loading auth data:", error);
        setStatus("unauthenticated");
      }
    };
    
    loadUserData();
  }, []);

  // Función para iniciar sesión
  const signIn = async (email: string, password: string): Promise<User> => {
    // En una implementación real, aquí se haría una llamada a la API
    // Para esta demo, simulamos una respuesta exitosa
    
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        try {
          // Validación simple
          if (!email || !password) {
            throw new Error("Email y contraseña son requeridos");
          }
          
          if (password.length < 6) {
            throw new Error("La contraseña debe tener al menos 6 caracteres");
          }
          
          // Usuario simulado
          const newUser: User = {
            id: `user_${Date.now()}`,
            email,
          };
          
          setUser(newUser);
          setStatus("authenticated");
          
          // Guardar en localStorage
          localStorage.setItem("autobisnes_user", JSON.stringify(newUser));
          
          resolve(newUser);
        } catch (error) {
          reject(error);
        }
      }, 500); // Retraso simulado
    });
  };

  // Función para registrarse
  const signUp = async (email: string, password: string, name?: string): Promise<User> => {
    // Similar a signIn, pero para registro
    
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        try {
          // Validación simple
          if (!email || !password) {
            throw new Error("Email y contraseña son requeridos");
          }
          
          if (password.length < 6) {
            throw new Error("La contraseña debe tener al menos 6 caracteres");
          }
          
          // Usuario simulado
          const newUser: User = {
            id: `user_${Date.now()}`,
            email,
            name,
          };
          
          setUser(newUser);
          setStatus("authenticated");
          
          // Guardar en localStorage
          localStorage.setItem("autobisnes_user", JSON.stringify(newUser));
          
          resolve(newUser);
        } catch (error) {
          reject(error);
        }
      }, 500); // Retraso simulado
    });
  };

  // Función para cerrar sesión
  const signOut = async (): Promise<void> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        setUser(null);
        setStatus("unauthenticated");
        localStorage.removeItem("autobisnes_user");
        // No eliminamos la API key al cerrar sesión para mantenerla guardada
        resolve();
      }, 300); // Retraso simulado
    });
  };

  // Función para actualizar la API key
  const updateApiKey = async (key: string): Promise<void> => {
    return new Promise((resolve, reject) => {
      try {
        // Validar que la API key tenga el formato correcto
        if (!key.startsWith("sk-")) {
          throw new Error("La API key debe comenzar con 'sk-'");
        }
        
        setApiKey(key);
        localStorage.setItem("autobisnes_api_key", key);
        resolve();
      } catch (error) {
        reject(error);
      }
    });
  };

  // Valor del contexto
  const value = {
    user,
    status,
    apiKey,
    signIn,
    signUp,
    signOut,
    updateApiKey,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth debe ser utilizado dentro de un AuthProvider");
  }
  return context;
};