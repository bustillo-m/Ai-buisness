import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth-context";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, MessageSquare, User, Settings, LogOut, Home, CreditCard } from "lucide-react";

export function Navbar() {
  const { user, status, signOut } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[240px] sm:w-[300px]">
              <nav className="flex flex-col gap-4 mt-6">
                <Link to="/" onClick={() => setIsOpen(false)} className="flex items-center gap-2 px-2 py-1 rounded-md hover:bg-accent">
                  <Home className="h-5 w-5" />
                  <span>Inicio</span>
                </Link>
                <Link to="/chat" onClick={() => setIsOpen(false)} className="flex items-center gap-2 px-2 py-1 rounded-md hover:bg-accent">
                  <MessageSquare className="h-5 w-5" />
                  <span>Chat IA</span>
                </Link>
                <Link to="/precios" onClick={() => setIsOpen(false)} className="flex items-center gap-2 px-2 py-1 rounded-md hover:bg-accent">
                  <CreditCard className="h-5 w-5" />
                  <span>Precios</span>
                </Link>
                {status === "authenticated" && (
                  <Link to="/configuracion" onClick={() => setIsOpen(false)} className="flex items-center gap-2 px-2 py-1 rounded-md hover:bg-accent">
                    <Settings className="h-5 w-5" />
                    <span>Configuración</span>
                  </Link>
                )}
              </nav>
            </SheetContent>
          </Sheet>
          <Link to="/" className="flex items-center gap-2">
            <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">Autobisnes</span>
          </Link>
        </div>

        <nav className="hidden md:flex items-center gap-6">
          <Link to="/" className="text-sm font-medium hover:text-primary">Inicio</Link>
          <Link to="/chat" className="text-sm font-medium hover:text-primary">Chat IA</Link>
          <Link to="/precios" className="text-sm font-medium hover:text-primary">Precios</Link>
        </nav>

        <div className="flex items-center gap-2">
          {status === "unauthenticated" ? (
            <>
              <Link to="/login">
                <Button variant="outline">Iniciar Sesión</Button>
              </Link>
              <Link to="/register">
                <Button>Registrarse</Button>
              </Link>
            </>
          ) : status === "authenticated" ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon" className="rounded-full">
                  <User className="h-5 w-5" />
                  <span className="sr-only">Menu de usuario</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Mi Cuenta</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to="/configuracion" className="cursor-pointer w-full">
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Configuración</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => signOut()} className="cursor-pointer text-red-600">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Cerrar Sesión</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : null}
        </div>
      </div>
    </header>
  );
}