import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/lib/auth-context";
import { MessageSquare, Lightbulb, Rocket, BarChart, Award, ArrowRight } from "lucide-react";

export default function IndexPage() {
  const { status } = useAuth();

  const features = [
    {
      title: "Asistente IA para Negocios",
      description: "Consulta sobre estrategias de marketing, finanzas, operaciones y más con respuestas precisas y personalizadas.",
      icon: <MessageSquare className="h-10 w-10 text-blue-600" />,
    },
    {
      title: "Análisis de Ideas de Negocio",
      description: "Evalúa la viabilidad de nuevas ideas empresariales con análisis de mercado e identificación de oportunidades.",
      icon: <Lightbulb className="h-10 w-10 text-blue-600" />,
    },
    {
      title: "Planes Estratégicos",
      description: "Desarrolla planes de negocio completos y estrategias de crecimiento basadas en datos actualizados.",
      icon: <Rocket className="h-10 w-10 text-blue-600" />,
    },
    {
      title: "Análisis de Rendimiento",
      description: "Interpreta métricas y KPIs para optimizar el rendimiento de tu negocio y tomar mejores decisiones.",
      icon: <BarChart className="h-10 w-10 text-blue-600" />,
    },
  ];

  const testimonials = [
    {
      quote: "Autobisnes ha transformado completamente la forma en que gestiono mi empresa. Ahora tengo un consultor disponible 24/7.",
      author: "María González",
      role: "Fundadora de MG Digital",
    },
    {
      quote: "El análisis de mercado que me proporcionó la IA me ayudó a identificar una oportunidad que todos habíamos pasado por alto.",
      author: "Carlos Martínez",
      role: "CEO de TechSolutions",
    },
    {
      quote: "Increíble herramienta para empresas que no pueden permitirse consultores tradicionales. Vale cada céntimo.",
      author: "Laura Sánchez",
      role: "Propietaria de Artesanías LS",
    },
  ];

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-50 py-20 px-4">
        <div className="container max-w-screen-xl mx-auto">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="flex-1 space-y-6">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight">
                Tu consultor de negocios con <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">Inteligencia Artificial</span>
              </h1>
              
              <p className="text-xl text-muted-foreground max-w-2xl">
                Autobisnes te ayuda a tomar decisiones estratégicas, analizar oportunidades y optimizar tu negocio con inteligencia artificial avanzada.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <Link to={status === "authenticated" ? "/chat" : "/register"}>
                  <Button size="lg" className="gap-2">
                    {status === "authenticated" ? "Ir al Chat IA" : "Comenzar ahora"}
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
                <Link to="/precios">
                  <Button variant="outline" size="lg">
                    Ver planes y precios
                  </Button>
                </Link>
              </div>
            </div>
            
            <div className="flex-1 relative">
              <div className="relative w-full aspect-square max-w-md mx-auto">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-3xl opacity-20 blur-2xl"></div>
                <div className="relative border border-slate-200 bg-white p-8 rounded-3xl shadow-xl">
                  <div className="space-y-4">
                    <div className="flex gap-3">
                      <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                        <MessageSquare className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Autobisnes IA</p>
                        <p className="text-xs text-muted-foreground">Ahora</p>
                      </div>
                    </div>
                    <p className="text-sm">Según tu análisis financiero, te recomendaría reducir los gastos operativos en un 15% y reinvertir en marketing digital, donde estás viendo un ROI del 240% en el último trimestre.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="container max-w-screen-xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Todo lo que necesitas para impulsar tu negocio</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Autobisnes combina inteligencia artificial avanzada con conocimientos empresariales
              para ofrecerte soluciones adaptadas a tus necesidades.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border-0 bg-muted/50 hover:bg-muted transition-all">
                <CardContent className="pt-6">
                  <div className="mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-muted py-20 px-4">
        <div className="container max-w-screen-xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Lo que dicen nuestros clientes</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Descubre cómo Autobisnes está ayudando a empresarios y emprendedores a alcanzar sus metas.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-background">
                <CardContent className="pt-6 space-y-4">
                  <div className="flex justify-center mb-2">
                    <Award className="h-8 w-8 text-yellow-500" />
                  </div>
                  <p className="text-center italic">"{testimonial.quote}"</p>
                  <div className="text-center">
                    <p className="font-semibold">{testimonial.author}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="mt-16 text-center">
            <Link to={status === "authenticated" ? "/chat" : "/register"}>
              <Button size="lg">
                {status === "authenticated" ? "Ir al Chat IA" : "Probar Autobisnes ahora"}
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-blue-600 to-indigo-600 text-white">
        <div className="container max-w-screen-xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Potencia tu negocio con inteligencia artificial</h2>
          <p className="text-xl opacity-90 max-w-2xl mx-auto mb-8">
            Comienza a utilizar Autobisnes hoy mismo y transforma la forma en que gestionas tu empresa.
          </p>
          <Link to="/precios">
            <Button size="lg" variant="secondary" className="gap-2">
              Ver planes y precios
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}