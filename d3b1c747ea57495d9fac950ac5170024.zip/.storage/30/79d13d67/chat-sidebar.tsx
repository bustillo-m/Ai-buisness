import { Button } from "@/components/ui/button";
import { useChat } from "@/lib/chat-context";
import { PlusCircle, MessageSquare, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { format } from "date-fns";
import { es } from "date-fns/locale";

export function ChatSidebar() {
  const { sessions, currentSession, createSession, selectSession, deleteSession } = useChat();

  // Formatear fecha para mostrar
  const formatSessionDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return format(date, "d 'de' MMMM", { locale: es });
  };

  return (
    <div className="flex flex-col h-full bg-muted/40">
      <div className="p-4 border-b">
        <Button 
          onClick={() => createSession()} 
          className="w-full justify-start" 
          variant="default"
        >
          <PlusCircle className="mr-2 h-4 w-4" />
          Nueva conversación
        </Button>
      </div>
      
      <ScrollArea className="flex-1 p-3">
        {sessions.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-center p-4">
            <MessageSquare className="h-8 w-8 text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">
              No hay conversaciones aún.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {sessions.map((session) => (
              <div 
                key={session.id} 
                className={cn(
                  "flex items-center justify-between rounded-md p-3 text-sm cursor-pointer",
                  currentSession?.id === session.id
                    ? "bg-accent"
                    : "hover:bg-muted"
                )}
                onClick={() => selectSession(session.id)}
              >
                <div className="flex flex-col overflow-hidden">
                  <span className="truncate font-medium">{session.title}</span>
                  <span className="text-xs text-muted-foreground">
                    {formatSessionDate(session.createdAt)}
                  </span>
                </div>
                
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 opacity-0 group-hover:opacity-100 hover:opacity-100"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Trash2 className="h-4 w-4" />
                      <span className="sr-only">Eliminar</span>
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>¿Eliminar esta conversación?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Esta acción no se puede deshacer. Esto eliminará permanentemente esta conversación
                        y todos sus mensajes.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction 
                        onClick={() => deleteSession(session.id)}
                        className="bg-destructive hover:bg-destructive/90"
                      >
                        Eliminar
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}