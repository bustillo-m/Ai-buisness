import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Message, ChatSession } from "./types";
import { useAuth } from "./auth-context";

interface ChatContextType {
  sessions: ChatSession[];
  currentSessionId: string | null;
  messages: Message[];
  isLoading: boolean;
  error: string | null;
  createNewSession: () => void;
  selectSession: (sessionId: string) => void;
  deleteSession: (sessionId: string) => void;
  sendMessage: (content: string) => Promise<void>;
  clearMessages: () => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export function ChatProvider({ children }: { children: ReactNode }) {
  const { apiKey, user } = useAuth();
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Cargar sesiones al iniciar
  useEffect(() => {
    if (user) {
      const savedSessions = localStorage.getItem(`autobisnes_sessions_${user.id}`);
      if (savedSessions) {
        const parsedSessions = JSON.parse(savedSessions);
        setSessions(parsedSessions);
        
        // Establecer la sesión actual si hay sesiones guardadas
        if (parsedSessions.length > 0) {
          const lastSessionId = localStorage.getItem(`autobisnes_last_session_${user.id}`);
          if (lastSessionId && parsedSessions.some((s: ChatSession) => s.id === lastSessionId)) {
            setCurrentSessionId(lastSessionId);
          } else {
            setCurrentSessionId(parsedSessions[0].id);
          }
        } else {
          createNewSession();
        }
      } else {
        createNewSession();
      }
    }
  }, [user]);

  // Guardar sesiones cuando cambian
  useEffect(() => {
    if (user && sessions.length > 0) {
      localStorage.setItem(`autobisnes_sessions_${user.id}`, JSON.stringify(sessions));
    }
  }, [sessions, user]);

  // Guardar la última sesión utilizada
  useEffect(() => {
    if (user && currentSessionId) {
      localStorage.setItem(`autobisnes_last_session_${user.id}`, currentSessionId);
    }
  }, [currentSessionId, user]);

  const createNewSession = () => {
    const newSession: ChatSession = {
      id: `session_${Date.now()}`,
      title: `Nueva conversación ${sessions.length + 1}`,
      messages: [{
        id: `msg_${Date.now()}`,
        role: 'system',
        content: 'Soy Autobisnes, tu asistente de inteligencia artificial profesional para empresas. ¿En qué puedo ayudarte hoy?',
        timestamp: Date.now()
      }],
      createdAt: Date.now()
    };
    
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
  };

  const selectSession = (sessionId: string) => {
    setCurrentSessionId(sessionId);
  };

  const deleteSession = (sessionId: string) => {
    setSessions(prev => prev.filter(session => session.id !== sessionId));
    
    if (currentSessionId === sessionId) {
      const remainingSessions = sessions.filter(session => session.id !== sessionId);
      if (remainingSessions.length > 0) {
        setCurrentSessionId(remainingSessions[0].id);
      } else {
        createNewSession();
      }
    }
  };

  const getCurrentMessages = (): Message[] => {
    if (!currentSessionId) return [];
    const currentSession = sessions.find(session => session.id === currentSessionId);
    return currentSession ? currentSession.messages : [];
  };

  const updateSessionMessages = (sessionId: string, newMessages: Message[]) => {
    setSessions(prev => prev.map(session => 
      session.id === sessionId
        ? { ...session, messages: newMessages }
        : session
    ));
  };

  const sendMessage = async (content: string) => {
    if (!apiKey) {
      setError("Necesitas configurar tu API Key de OpenAI. Ve a la configuración para añadirla.");
      return;
    }

    if (!currentSessionId) {
      createNewSession();
      return;
    }

    // Añadir mensaje del usuario
    const userMessage: Message = {
      id: `msg_user_${Date.now()}`,
      role: 'user',
      content,
      timestamp: Date.now()
    };

    const currentMessages = getCurrentMessages();
    const updatedMessages = [...currentMessages, userMessage];
    updateSessionMessages(currentSessionId, updatedMessages);

    setIsLoading(true);
    setError(null);

    try {
      // En una implementación real, esto haría una llamada a la API de OpenAI
      // Por ahora simulamos una respuesta después de un breve retraso
      await new Promise(resolve => setTimeout(resolve, 1000));

      const simulatedResponse: Message = {
        id: `msg_assistant_${Date.now()}`,
        role: 'assistant',
        content: `Esta es una respuesta simulada. En una implementación real, aquí verías la respuesta de la API de OpenAI usando tu clave API.`,
        timestamp: Date.now()
      };

      updateSessionMessages(currentSessionId, [...updatedMessages, simulatedResponse]);
    } catch (err) {
      setError("Error al enviar mensaje. Por favor, intenta de nuevo.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const clearMessages = () => {
    if (currentSessionId) {
      const initialMessage: Message = {
        id: `msg_${Date.now()}`,
        role: 'system',
        content: 'Soy Autobisnes, tu asistente de inteligencia artificial profesional para empresas. ¿En qué puedo ayudarte hoy?',
        timestamp: Date.now()
      };
      
      updateSessionMessages(currentSessionId, [initialMessage]);
    }
  };

  return (
    <ChatContext.Provider
      value={{
        sessions,
        currentSessionId,
        messages: getCurrentMessages(),
        isLoading,
        error,
        createNewSession,
        selectSession,
        deleteSession,
        sendMessage,
        clearMessages
      }}
    >
      {children}
    </ChatContext.Provider>
  );
}

export function useChat() {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error("useChat debe ser usado dentro de un ChatProvider");
  }
  return context;
}