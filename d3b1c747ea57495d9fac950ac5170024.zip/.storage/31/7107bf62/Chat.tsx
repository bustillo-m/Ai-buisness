import { useEffect } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "@/lib/auth-context";
import { ChatInterface } from "@/components/chat/chat-interface";
import { ChatSidebar } from "@/components/chat/chat-sidebar";
import { Button } from "@/components/ui/button";
import { Settings } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function ChatPage() {
  const { user, status, apiKey } = useAuth();
  const navigate = useNavigate();

  // Verificar autenticación
  if (status === "unauthenticated") {
    return <Navigate to="/login" replace />;
  }

  // Redirigir a configuración si no hay API key configurada
  useEffect(() => {
    if (status === "authenticated" && !apiKey) {
      navigate("/configuracion", { state: { missingApiKey: true } });
    }
  }, [status, apiKey, navigate]);

  return (
    <div className="flex h-[calc(100vh-4rem)] overflow-hidden">
      {/* Barra lateral con sesiones de chat */}
      <div className="hidden md:block w-64 border-r">
        <ChatSidebar />
      </div>
      
      {/* Área principal de chat */}
      <div className="flex-1 flex flex-col">
        {/* Barra superior con información */}
        <div className="border-b p-4 flex items-center justify-between">
          <h1 className="text-xl font-semibold">Chat IA</h1>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => navigate("/configuracion")}
            className="gap-2"
          >
            <Settings className="h-4 w-4" />
            <span className="hidden sm:inline">Configuración</span>
          </Button>
        </div>
        
        {/* Interfaz de chat */}
        <div className="flex-1 overflow-hidden">
          <ChatInterface />
        </div>
      </div>
    </div>
  );
}