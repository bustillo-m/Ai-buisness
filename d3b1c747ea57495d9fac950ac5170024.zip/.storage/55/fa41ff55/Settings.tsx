import { useState, useEffect } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, Check, Eye, EyeOff, Info } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface LocationState {
  newUser?: boolean;
  missingApiKey?: boolean;
}

export default function SettingsPage() {
  const location = useLocation();
  const state = location.state as LocationState;
  const { user, status, apiKey, updateApiKey } = useAuth();
  
  const [key, setKey] = useState("");
  const [name, setName] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isDefaultKey, setIsDefaultKey] = useState(false);

  // Inicializar valores con datos del usuario
  useEffect(() => {
    if (user?.name) {
      setName(user.name);
    }
    if (apiKey) {
      setKey(apiKey);
      // Verificar si es la API key predeterminada
      setIsDefaultKey(apiKey === "sk-default-autobisnes-api-key-1234567890");
    }
  }, [user, apiKey]);

  // Verificar autenticación
  if (status === "unauthenticated") {
    return <Navigate to="/login" replace />;
  }

  const handleUpdateApiKey = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      setIsLoading(true);
      setError(null);
      await updateApiKey(key);
      setSuccess(true);
      setIsDefaultKey(key === "sk-default-autobisnes-api-key-1234567890");
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : "Error al actualizar la API key");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container max-w-screen-md py-10">
      <h1 className="text-3xl font-bold mb-6">Configuración</h1>

      {/* Mensajes de aviso */}
      {state?.newUser && (
        <Alert className="mb-6">
          <Check className="h-4 w-4" />
          <AlertDescription>
            ¡Registro exitoso! Ya puedes comenzar a utilizar el chat IA con la API key predeterminada o configurar tu propia API key.
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="api" className="space-y-6">
        <TabsList>
          <TabsTrigger value="api">API Key</TabsTrigger>
          <TabsTrigger value="account">Cuenta</TabsTrigger>
        </TabsList>
        
        {/* Pestaña de API Key */}
        <TabsContent value="api">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de API Key</CardTitle>
              <CardDescription>
                El sistema ya tiene configurada una API key predeterminada, pero puedes configurar tu propia API key para conectarte al servicio IA si lo deseas.
              </CardDescription>
            </CardHeader>
            
            <form onSubmit={handleUpdateApiKey}>
              <CardContent className="space-y-4">
                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
                
                {success && (
                  <Alert className="bg-green-50 border-green-300">
                    <Check className="h-4 w-4 text-green-600" />
                    <AlertDescription className="text-green-600">
                      API key actualizada exitosamente
                    </AlertDescription>
                  </Alert>
                )}

                {isDefaultKey && (
                  <Alert>
                    <Info className="h-4 w-4" />
                    <AlertDescription>
                      Estás usando la API key predeterminada proporcionada por Autobisnes. Puedes usarla para probar el sistema o configurar tu propia API key.
                    </AlertDescription>
                  </Alert>
                )}
                
                <div className="space-y-2">
                  <Label htmlFor="api-key">API Key</Label>
                  <div className="relative">
                    <Input
                      id="api-key"
                      type={showKey ? "text" : "password"}
                      placeholder="sk-..."
                      value={key}
                      onChange={(e) => setKey(e.target.value)}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-2 top-1/2 -translate-y-1/2"
                      onClick={() => setShowKey(!showKey)}
                    >
                      {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      <span className="sr-only">{showKey ? "Ocultar" : "Mostrar"}</span>
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Tu API key está almacenada de forma segura en tu navegador.
                  </p>
                </div>
              </CardContent>
              
              <CardFooter>
                <Button type="submit" disabled={isLoading || !key}>
                  {isLoading ? "Guardando..." : "Guardar API Key"}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>
        
        {/* Pestaña de Cuenta */}
        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle>Información de la cuenta</CardTitle>
              <CardDescription>
                Administra tu información personal y preferencias.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nombre</Label>
                <Input
                  id="name"
                  placeholder="Tu nombre"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Correo electrónico</Label>
                <Input
                  id="email"
                  type="email"
                  value={user?.email || ""}
                  disabled
                  className="opacity-70"
                />
                <p className="text-sm text-muted-foreground">
                  El correo electrónico no se puede modificar.
                </p>
              </div>
            </CardContent>
            <CardFooter>
              <Button disabled>Actualizar información</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}