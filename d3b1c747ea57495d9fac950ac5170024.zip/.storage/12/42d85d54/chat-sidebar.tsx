import { useState } from "react";
import { useChat } from "@/lib/chat-context";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { PlusCircle, Trash, MessageSquare } from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { format } from "date-fns";
import { es } from "date-fns/locale";

interface ChatSidebarProps {
  onSelectSession?: () => void;
}

export function ChatSidebar({ onSelectSession }: ChatSidebarProps = {}) {
  const { sessions, currentSessionId, createNewSession, selectSession, deleteSession } = useChat();

  const handleSelectSession = (sessionId: string) => {
    selectSession(sessionId);
    onSelectSession?.();
  };

  return (
    <div className="flex flex-col h-full w-full">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="text-sm font-semibold">Conversaciones</h2>
        <Button
          onClick={createNewSession}
          size="sm"
          variant="outline"
          className="h-8 gap-1"
        >
          <PlusCircle className="h-4 w-4" />
          <span>Nuevo</span>
        </Button>
      </div>
      
      <ScrollArea className="flex-1">
        {sessions.length > 0 ? (
          <div className="p-2">
            {sessions.map((session) => {
              const isActive = session.id === currentSessionId;
              const date = new Date(session.createdAt);
              
              return (
                <div key={session.id} className="mb-1">
                  <button
                    onClick={() => handleSelectSession(session.id)}
                    className={`w-full text-left px-2 py-2 rounded-lg text-sm ${
                      isActive
                        ? "bg-accent text-accent-foreground"
                        : "hover:bg-accent/50"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 truncate">
                        <MessageSquare className="h-4 w-4 flex-shrink-0" />
                        <span className="truncate">{session.title}</span>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 opacity-0 group-hover:opacity-100 focus:opacity-100"
                          >
                            <Trash className="h-4 w-4" />
                            <span className="sr-only">Eliminar</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteSession(session.id);
                            }}
                            className="text-red-600 focus:text-red-600"
                          >
                            Eliminar conversación
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">
                      {format(date, "d MMM, HH:mm", { locale: es })}
                    </div>
                  </button>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex items-center justify-center h-full">
            <div className="text-center p-4">
              <MessageSquare className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">No hay conversaciones</p>
            </div>
          </div>
        )}
      </ScrollArea>
    </div>
  );
}