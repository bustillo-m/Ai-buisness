import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, CheckCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/components/ui/use-toast";

export default function SettingsPage() {
  const { user, apiKey, updateApiKey, status } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  
  const [newApiKey, setNewApiKey] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Verificar si el usuario está autenticado
  useEffect(() => {
    if (status === "unauthenticated") {
      navigate("/login");
    } else if (apiKey) {
      setNewApiKey(apiKey);
    }
  }, [status, navigate, apiKey]);

  // Verificar si es un usuario nuevo
  useEffect(() => {
    const isNewUser = location.state?.newUser;
    if (isNewUser) {
      toast({
        title: "¡Cuenta creada con éxito!",
        description: "Configura tu API Key de OpenAI para comenzar a usar el chat.",
      });
    }
  }, [location, toast]);

  const handleSubmitApiKey = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      setIsLoading(true);
      setError(null);
      setSuccess(null);
      
      await updateApiKey(newApiKey);
      
      setSuccess("API Key actualizada correctamente.");
      
      // Dar tiempo para mostrar el mensaje de éxito antes de redirigir
      setTimeout(() => {
        navigate("/chat");
      }, 1500);
    } catch (err) {
      setError("Error al actualizar la API Key.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  // Si está cargando, mostrar un indicador de carga
  if (status === "loading") {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-64px-56px)]">
        <div className="text-center">
          <div className="w-12 h-12 rounded-full border-4 border-blue-600 border-t-transparent animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Cargando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container max-w-4xl py-8 px-4">
      <h1 className="text-3xl font-bold mb-8">Configuración</h1>
      
      <Tabs defaultValue="api-key">
        <TabsList className="mb-6">
          <TabsTrigger value="api-key">API Key</TabsTrigger>
          <TabsTrigger value="account">Cuenta</TabsTrigger>
        </TabsList>
        
        <TabsContent value="api-key">
          <Card>
            <CardHeader>
              <CardTitle>API Key de OpenAI</CardTitle>
              <CardDescription>
                Configura tu API Key para utilizar el chat de Autobisnes
              </CardDescription>
            </CardHeader>
            
            <form onSubmit={handleSubmitApiKey}>
              <CardContent className="space-y-4">
                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
                
                {success && (
                  <Alert variant="default" className="border-green-600 bg-green-50 text-green-700">
                    <CheckCircle className="h-4 w-4" />
                    <AlertDescription>{success}</AlertDescription>
                  </Alert>
                )}
                
                <div className="space-y-1">
                  <Label htmlFor="api-key">API Key</Label>
                  <Input
                    id="api-key"
                    type="password"
                    placeholder="sk-..."
                    value={newApiKey}
                    onChange={(e) => setNewApiKey(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Puedes obtener tu API Key en{" "}
                    <a 
                      href="https://platform.openai.com/account/api-keys" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      platform.openai.com/account/api-keys
                    </a>
                  </p>
                </div>
              </CardContent>
              
              <CardFooter>
                <Button type="submit" disabled={isLoading || !newApiKey}>
                  {isLoading ? "Guardando..." : "Guardar"}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>
        
        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle>Información de la cuenta</CardTitle>
              <CardDescription>
                Gestiona tus datos personales y preferencias
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1">
                <Label>Correo electrónico</Label>
                <div className="p-2 border rounded-md bg-gray-50 dark:bg-gray-900">
                  {user?.email || "No disponible"}
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => navigate("/chat")}>
                Cancelar
              </Button>
              <Button variant="destructive" onClick={() => {}}>
                Cerrar sesión
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}