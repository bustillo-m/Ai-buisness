import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Menu, MessageSquare, Settings, LogOut } from "lucide-react";

export function Navbar() {
  const navigate = useNavigate();
  const { user, status, signOut } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  // Maneja el cierre de Sheet en dispositivos móviles al hacer clic en un enlace
  const handleLinkClick = () => {
    setIsOpen(false);
  };

  // Maneja el cierre de sesión
  const handleSignOut = async () => {
    try {
      await signOut();
      navigate("/");
    } catch (error) {
      console.error("Error al cerrar sesión:", error);
    }
  };

  // Obtiene las iniciales del nombre de usuario para el avatar
  const getUserInitials = () => {
    if (!user?.name) return "U";
    
    const nameParts = user.name.split(" ");
    if (nameParts.length >= 2) {
      return `${nameParts[0][0]}${nameParts[1][0]}`.toUpperCase();
    }
    return user.name.substring(0, 2).toUpperCase();
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        {/* Logo y nombre */}
        <div className="flex items-center gap-2">
          <Link to="/" className="flex items-center gap-2">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-1.5 rounded">
              <MessageSquare className="h-5 w-5" />
            </div>
            <span className="font-bold text-xl">Autobisnes</span>
          </Link>
        </div>

        {/* Links de navegación para desktop */}
        <nav className="hidden md:flex items-center gap-6">
          <Link to="/" className="text-sm font-medium">
            Inicio
          </Link>
          {status === "authenticated" && (
            <Link to="/chat" className="text-sm font-medium">
              Chat IA
            </Link>
          )}
          <Link to="/precios" className="text-sm font-medium">
            Precios
          </Link>
        </nav>

        {/* Botones de acción */}
        <div className="flex items-center gap-2">
          {status === "authenticated" ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 w-10 rounded-full" aria-label="Menú de usuario">
                  <Avatar>
                    <AvatarFallback className="bg-blue-100 text-blue-800">
                      {getUserInitials()}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <div className="flex items-center justify-start gap-2 p-2">
                  <div className="flex flex-col space-y-1 leading-none">
                    {user?.name && (
                      <p className="font-medium">{user.name}</p>
                    )}
                    {user?.email && (
                      <p className="w-[200px] truncate text-sm text-muted-foreground">
                        {user.email}
                      </p>
                    )}
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to="/chat" className="flex w-full cursor-pointer items-center">
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Chat IA
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/configuracion" className="flex w-full cursor-pointer items-center">
                    <Settings className="mr-2 h-4 w-4" />
                    Configuración
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  className="cursor-pointer text-red-600 focus:text-red-600"
                  onClick={handleSignOut}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Cerrar sesión
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <>
              <Link to="/login" className="hidden md:block">
                <Button variant="ghost" size="sm">
                  Iniciar sesión
                </Button>
              </Link>
              <Link to="/register">
                <Button size="sm" className="hidden md:inline-flex">
                  Registro
                </Button>
              </Link>
            </>
          )}
          
          {/* Menu móvil */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Abrir menú</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px]">
              <nav className="flex flex-col gap-4 mt-8">
                <Link to="/" className="text-lg font-medium" onClick={handleLinkClick}>
                  Inicio
                </Link>
                {status === "authenticated" && (
                  <Link to="/chat" className="text-lg font-medium" onClick={handleLinkClick}>
                    Chat IA
                  </Link>
                )}
                <Link to="/precios" className="text-lg font-medium" onClick={handleLinkClick}>
                  Precios
                </Link>
                
                {status === "authenticated" ? (
                  <>
                    <Link to="/configuracion" className="text-lg font-medium" onClick={handleLinkClick}>
                      Configuración
                    </Link>
                    <button 
                      className="text-lg font-medium text-red-600 text-left"
                      onClick={() => {
                        handleSignOut();
                        handleLinkClick();
                      }}
                    >
                      Cerrar sesión
                    </button>
                  </>
                ) : (
                  <>
                    <Link to="/login" className="text-lg font-medium" onClick={handleLinkClick}>
                      Iniciar sesión
                    </Link>
                    <Link to="/register" className="text-lg font-medium" onClick={handleLinkClick}>
                      Registro
                    </Link>
                  </>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}