import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { MainLayout } from './components/layout/main-layout';
import { AuthProvider } from './lib/auth-context';
import { ChatProvider } from './lib/chat-context';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Toaster } from '@/components/ui/sonner';

import IndexPage from './pages/Index';
import ChatPage from './pages/Chat';
import LoginPage from './pages/Login';
import RegisterPage from './pages/Register';
import SettingsPage from './pages/Settings';
import PricingPage from './pages/Pricing';
import NotFound from './pages/NotFound';

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <ChatProvider>
          <BrowserRouter>
            <Routes>
              <Route element={<MainLayout />}>
                <Route path="/" element={<IndexPage />} />
                <Route path="/chat" element={<ChatPage />} />
                <Route path="/configuracion" element={<SettingsPage />} />
                <Route path="/precios" element={<PricingPage />} />
                <Route path="*" element={<NotFound />} />
              </Route>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
            </Routes>
          </BrowserRouter>
          <Toaster />
        </ChatProvider>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;