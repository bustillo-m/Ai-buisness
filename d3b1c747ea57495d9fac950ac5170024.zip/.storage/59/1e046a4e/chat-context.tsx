import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useAuth } from "./auth-context";
import { ChatSession, Message } from "./types";

interface ChatContextType {
  sessions: ChatSession[];
  currentSession: ChatSession | null;
  isLoading: boolean;
  createSession: () => ChatSession;
  selectSession: (sessionId: string) => void;
  deleteSession: (sessionId: string) => void;
  sendMessage: (content: string) => Promise<void>;
  clearMessages: () => void;
}

interface OpenAIMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

interface OpenAICompletionResponse {
  choices: {
    message: {
      role: string;
      content: string;
    };
  }[];
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

const STORAGE_KEY = "autobisnes_chat_sessions";

export function ChatProvider({ children }: { children: ReactNode }) {
  const { user, apiKey, status } = useAuth();
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSession, setCurrentSession] = useState<ChatSession | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Cargar sesiones de chat desde localStorage
  useEffect(() => {
    if (status === "authenticated") {
      try {
        const storedSessions = localStorage.getItem(`${STORAGE_KEY}_${user?.id}`);
        if (storedSessions) {
          const parsedSessions: ChatSession[] = JSON.parse(storedSessions);
          setSessions(parsedSessions);
          
          // Establecer la sesión actual (última utilizada o la primera)
          const lastSessionId = localStorage.getItem(`${STORAGE_KEY}_current_${user?.id}`);
          const sessionToSelect = lastSessionId 
            ? parsedSessions.find(s => s.id === lastSessionId) 
            : parsedSessions[0];
            
          if (sessionToSelect) {
            setCurrentSession(sessionToSelect);
          } else if (parsedSessions.length === 0) {
            // Crear una nueva sesión si no hay ninguna
            const newSession = createNewSession();
            setSessions([newSession]);
            setCurrentSession(newSession);
            saveSessions([newSession], newSession.id);
          }
        } else {
          // No hay sesiones, crear una nueva
          const newSession = createNewSession();
          setSessions([newSession]);
          setCurrentSession(newSession);
          saveSessions([newSession], newSession.id);
        }
      } catch (error) {
        console.error("Error loading chat sessions:", error);
      }
    }
  }, [user, status]);

  // Guardar sesiones en localStorage
  const saveSessions = (sessionsList: ChatSession[], currentId: string | null = null) => {
    if (user) {
      localStorage.setItem(`${STORAGE_KEY}_${user.id}`, JSON.stringify(sessionsList));
      if (currentId) {
        localStorage.setItem(`${STORAGE_KEY}_current_${user.id}`, currentId);
      }
    }
  };

  // Crear una nueva sesión
  const createNewSession = (): ChatSession => {
    const now = Date.now();
    return {
      id: `session_${now}`,
      title: `Nueva conversación`,
      messages: [],
      createdAt: now,
      updatedAt: now,
    };
  };

  // Crear una nueva sesión y seleccionarla
  const createSession = (): ChatSession => {
    const newSession = createNewSession();
    const updatedSessions = [...sessions, newSession];
    setSessions(updatedSessions);
    setCurrentSession(newSession);
    saveSessions(updatedSessions, newSession.id);
    return newSession;
  };

  // Seleccionar una sesión existente
  const selectSession = (sessionId: string) => {
    const session = sessions.find((s) => s.id === sessionId);
    if (session) {
      setCurrentSession(session);
      localStorage.setItem(`${STORAGE_KEY}_current_${user?.id}`, sessionId);
    }
  };

  // Eliminar una sesión
  const deleteSession = (sessionId: string) => {
    const updatedSessions = sessions.filter((s) => s.id !== sessionId);
    setSessions(updatedSessions);
    
    if (currentSession?.id === sessionId) {
      const newCurrentSession = updatedSessions.length > 0 ? updatedSessions[0] : null;
      setCurrentSession(newCurrentSession);
      saveSessions(updatedSessions, newCurrentSession?.id || null);
    } else {
      saveSessions(updatedSessions, currentSession?.id || null);
    }
  };

  // Llamada a la API de OpenAI
  const callOpenAI = async (messages: OpenAIMessage[]): Promise<string> => {
    try {
      // Usar el endpoint de OpenAI para chat completions
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "gpt-3.5-turbo", // Modelo por defecto
          messages: messages,
          max_tokens: 1000,
          temperature: 0.7,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          `Error en la API de OpenAI: ${errorData.error?.message || response.statusText}`
        );
      }

      const data = await response.json() as OpenAICompletionResponse;
      return data.choices[0].message.content.trim();
    } catch (error) {
      console.error("Error llamando a la API de OpenAI:", error);
      throw error;
    }
  };

  // Enviar un mensaje a la IA
  const sendMessage = async (content: string): Promise<void> => {
    if (!currentSession || !apiKey) return;

    try {
      setIsLoading(true);

      // Crear mensaje del usuario
      const userMessage: Message = {
        id: `msg_${Date.now()}`,
        content,
        role: "user",
        timestamp: Date.now(),
      };

      // Actualizar la sesión con el mensaje del usuario
      const sessionWithUserMsg = {
        ...currentSession,
        messages: [...currentSession.messages, userMessage],
        updatedAt: Date.now(),
      };
      
      // Si el título es genérico y este es el primer mensaje, generar un título basado en el contenido
      let updatedTitle = sessionWithUserMsg.title;
      if (sessionWithUserMsg.title === "Nueva conversación" && sessionWithUserMsg.messages.length === 1) {
        updatedTitle = content.length > 30 ? `${content.substring(0, 30)}...` : content;
        sessionWithUserMsg.title = updatedTitle;
      }

      // Actualizar la sesión actual y las sesiones
      setCurrentSession(sessionWithUserMsg);
      const updatedSessions = sessions.map(s => 
        s.id === currentSession.id ? sessionWithUserMsg : s
      );
      setSessions(updatedSessions);
      saveSessions(updatedSessions, sessionWithUserMsg.id);

      // Preparar mensajes para la API de OpenAI
      const openAIMessages: OpenAIMessage[] = [
        {
          role: "system",
          content: "Eres el asistente IA de Autobisnes, especializado en ayudar a emprendedores y empresas con estrategias de negocio, marketing, análisis de datos y tendencias del mercado. Proporciona respuestas útiles, detalladas y relevantes."
        },
        ...currentSession.messages.map(msg => ({
          role: msg.role,
          content: msg.content
        })),
        { role: "user", content }
      ];

      try {
        // Llamar a la API de OpenAI
        const responseContent = await callOpenAI(openAIMessages);

        // Crear mensaje de respuesta con el contenido de la API
        const assistantMessage: Message = {
          id: `msg_${Date.now()}`,
          content: responseContent,
          role: "assistant",
          timestamp: Date.now(),
        };

        // Actualizar la sesión con la respuesta
        const sessionWithBothMsgs = {
          ...sessionWithUserMsg,
          messages: [...sessionWithUserMsg.messages, assistantMessage],
          updatedAt: Date.now(),
        };

        // Actualizar la sesión actual y las sesiones
        setCurrentSession(sessionWithBothMsgs);
        const finalUpdatedSessions = updatedSessions.map(s => 
          s.id === currentSession.id ? sessionWithBothMsgs : s
        );
        setSessions(finalUpdatedSessions);
        saveSessions(finalUpdatedSessions, sessionWithBothMsgs.id);
      } catch (apiError) {
        console.error("Error en la comunicación con OpenAI:", apiError);
        
        // Crear un mensaje de error como respuesta del asistente
        const errorMessage: Message = {
          id: `msg_${Date.now()}`,
          content: "Lo siento, ha ocurrido un error al procesar tu solicitud. Por favor, verifica tu API key en la configuración o inténtalo de nuevo más tarde.",
          role: "assistant",
          timestamp: Date.now(),
        };

        // Actualizar la sesión con el mensaje de error
        const sessionWithErrorMsg = {
          ...sessionWithUserMsg,
          messages: [...sessionWithUserMsg.messages, errorMessage],
          updatedAt: Date.now(),
        };

        setCurrentSession(sessionWithErrorMsg);
        const errorUpdatedSessions = updatedSessions.map(s => 
          s.id === currentSession.id ? sessionWithErrorMsg : s
        );
        setSessions(errorUpdatedSessions);
        saveSessions(errorUpdatedSessions, sessionWithErrorMsg.id);
      }

    } catch (error) {
      console.error("Error sending message:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Limpiar todos los mensajes de la sesión actual
  const clearMessages = () => {
    if (!currentSession) return;

    const clearedSession = {
      ...currentSession,
      messages: [],
      updatedAt: Date.now(),
    };

    setCurrentSession(clearedSession);
    const updatedSessions = sessions.map(s => 
      s.id === currentSession.id ? clearedSession : s
    );
    setSessions(updatedSessions);
    saveSessions(updatedSessions, clearedSession.id);
  };

  // Valor del contexto
  const value = {
    sessions,
    currentSession,
    isLoading,
    createSession,
    selectSession,
    deleteSession,
    sendMessage,
    clearMessages,
  };

  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
}

export const useChat = (): ChatContextType => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error("useChat debe ser utilizado dentro de un ChatProvider");
  }
  return context;
};