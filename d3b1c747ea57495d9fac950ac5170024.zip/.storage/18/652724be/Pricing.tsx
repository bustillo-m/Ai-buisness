import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, X } from "lucide-react";

export default function PricingPage() {
  const plans = [
    {
      name: "Básico",
      price: "0€",
      description: "Para probar la plataforma",
      features: [
        { name: "5 conversaciones al día", included: true },
        { name: "Acceso al asistente IA", included: true },
        { name: "Respuestas básicas", included: true },
        { name: "Historial de 24 horas", included: true },
        { name: "Soporte por email", included: false },
        { name: "Sin límite de caracteres", included: false },
        { name: "Análisis avanzado", included: false },
      ],
      buttonText: "Comenzar gratis",
      buttonLink: "/register",
      highlight: false,
    },
    {
      name: "Profesional",
      price: "29€",
      period: "/ mes",
      description: "Para empresas en crecimiento",
      features: [
        { name: "Conversaciones ilimitadas", included: true },
        { name: "Acceso completo al asistente IA", included: true },
        { name: "Respuestas avanzadas", included: true },
        { name: "Historial permanente", included: true },
        { name: "Soporte prioritario", included: true },
        { name: "Sin límite de caracteres", included: true },
        { name: "Análisis avanzado", included: false },
      ],
      buttonText: "Suscribirse",
      buttonLink: "/register",
      highlight: true,
    },
    {
      name: "Empresarial",
      price: "99€",
      period: "/ mes",
      description: "Para grandes organizaciones",
      features: [
        { name: "Todo lo del plan Profesional", included: true },
        { name: "Usuarios múltiples", included: true },
        { name: "API dedicada", included: true },
        { name: "Integraciones personalizadas", included: true },
        { name: "Soporte 24/7", included: true },
        { name: "Panel de administración", included: true },
        { name: "Análisis avanzado", included: true },
      ],
      buttonText: "Contactar ventas",
      buttonLink: "#",
      highlight: false,
    },
  ];

  return (
    <div className="container py-12 md:py-24 px-4">
      <div className="text-center space-y-3 mb-12">
        <h1 className="text-4xl font-bold">Planes y precios</h1>
        <p className="text-xl text-muted-foreground mx-auto max-w-[800px]">
          Elige el plan que mejor se adapte a las necesidades de tu empresa
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {plans.map((plan, index) => (
          <Card 
            key={index} 
            className={`flex flex-col ${
              plan.highlight 
                ? "border-blue-600 shadow-lg shadow-blue-100 dark:shadow-blue-900/20" 
                : ""
            }`}
          >
            <CardHeader>
              <CardTitle className="text-2xl">{plan.name}</CardTitle>
              <div className="mt-2">
                <span className="text-3xl font-bold">{plan.price}</span>
                {plan.period && <span className="text-muted-foreground">{plan.period}</span>}
              </div>
              <CardDescription className="mt-2">{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-3">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center gap-2">
                    {feature.included ? (
                      <Check className="h-4 w-4 text-green-600" />
                    ) : (
                      <X className="h-4 w-4 text-muted-foreground" />
                    )}
                    <span className={feature.included ? "" : "text-muted-foreground"}>
                      {feature.name}
                    </span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Link to={plan.buttonLink} className="w-full">
                <Button 
                  className={`w-full ${
                    plan.highlight 
                      ? "" 
                      : "bg-secondary hover:bg-secondary/90 text-secondary-foreground"
                  }`} 
                >
                  {plan.buttonText}
                </Button>
              </Link>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="mt-16 text-center">
        <h2 className="text-2xl font-bold mb-4">¿Preguntas? Estamos aquí para ayudarte</h2>
        <p className="text-muted-foreground mb-6">
          Nuestro equipo está disponible para ayudarte a encontrar la mejor solución para tu empresa
        </p>
        <Button variant="outline" size="lg">
          Contactar con ventas
        </Button>
      </div>
    </div>
  );
}