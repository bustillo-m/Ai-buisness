import { ReactNode } from "react";
import { Navbar } from "./navbar";
import { AuthProvider } from "@/lib/auth-context";
import { ChatProvider } from "@/lib/chat-context";

interface MainLayoutProps {
  children: ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  return (
    <AuthProvider>
      <ChatProvider>
        <div className="min-h-screen flex flex-col">
          <Navbar />
          <main className="flex-1">
            {children}
          </main>
          <footer className="border-t py-6 bg-background">
            <div className="container flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
              <p>© 2023 Autobisnes. Todos los derechos reservados.</p>
              <nav className="flex gap-4">
                <a href="#" className="hover:text-foreground">Términos</a>
                <a href="#" className="hover:text-foreground">Privacidad</a>
                <a href="#" className="hover:text-foreground">Contacto</a>
              </nav>
            </div>
          </footer>
        </div>
      </ChatProvider>
    </AuthProvider>
  );
}