import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Check } from "lucide-react";

export default function PricingPage() {
  const navigate = useNavigate();
  const { status } = useAuth();
  const [billingInterval, setBillingInterval] = useState<"monthly" | "annual">("monthly");

  const plans = [
    {
      name: "Básico",
      description: "Plan ideal para iniciarse en el mundo IA para negocios",
      price: { monthly: "0", annual: "0" },
      features: [
        "3 conversaciones IA por día",
        "Acceso a capacidades básicas de IA",
        "Soporte por email",
        "Acceso a la comunidad",
      ],
      buttonText: "Comenzar gratis",
      isPopular: false,
      colorClass: "",
    },
    {
      name: "Profesional",
      description: "Plan ideal para profesionales y pequeños negocios",
      price: { monthly: "29", annual: "290" },
      features: [
        "Conversaciones IA ilimitadas",
        "Acceso a todas las capacidades de IA",
        "Guardado y gestión de conversaciones",
        "Soporte prioritario",
        "Plantillas de negocio personalizadas",
      ],
      buttonText: "Empezar ahora",
      isPopular: true,
      colorClass: "border-blue-600",
    },
    {
      name: "Empresarial",
      description: "Para equipos y empresas que necesitan máxima potencia",
      price: { monthly: "99", annual: "990" },
      features: [
        "Todo lo incluido en Profesional",
        "Usuarios múltiples (5 incluidos)",
        "Integraciones empresariales",
        "Análisis avanzado de datos",
        "Personalización de la IA",
        "Soporte técnico dedicado",
      ],
      buttonText: "Contactar ventas",
      isPopular: false,
      colorClass: "",
    },
  ];

  const handlePlanSelect = (planName: string) => {
    if (status === "unauthenticated") {
      navigate("/register");
    } else {
      if (planName === "Básico") {
        navigate("/chat");
      } else if (planName === "Profesional") {
        window.alert("La funcionalidad de pago no está implementada en esta demo. Te redirigiremos al chat.");
        navigate("/chat");
      } else {
        window.alert("Gracias por tu interés en nuestro plan Empresarial. Un representante se pondrá en contacto contigo.");
        navigate("/");
      }
    }
  };

  return (
    <div className="py-12 px-4 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            Planes y precios
          </h1>
          <p className="mt-4 text-xl text-muted-foreground max-w-2xl mx-auto">
            Elige el plan que mejor se adapte a tus necesidades y comienza a potenciar tu negocio con IA.
          </p>
          
          <div className="mt-8 flex justify-center">
            <div className="inline-flex rounded-md p-1 bg-muted">
              <button
                onClick={() => setBillingInterval("monthly")}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  billingInterval === "monthly" 
                    ? "bg-background shadow-sm text-foreground" 
                    : "text-muted-foreground hover:bg-muted/80"
                }`}
              >
                Mensual
              </button>
              <button
                onClick={() => setBillingInterval("annual")}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  billingInterval === "annual" 
                    ? "bg-background shadow-sm text-foreground" 
                    : "text-muted-foreground hover:bg-muted/80"
                }`}
              >
                Anual <span className="text-emerald-600 font-medium">-17%</span>
              </button>
            </div>
          </div>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 mb-20">
          {plans.map((plan) => (
            <Card 
              key={plan.name}
              className={`relative flex flex-col ${
                plan.isPopular ? `border-2 ${plan.colorClass}` : ""
              }`}
            >
              {plan.isPopular && (
                <div className="absolute -top-5 left-0 right-0 flex justify-center">
                  <span className="bg-blue-600 text-white text-sm font-medium px-4 py-1 rounded-full shadow-sm">
                    Más popular
                  </span>
                </div>
              )}
              
              <CardHeader>
                <CardTitle>{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>
              
              <CardContent className="flex-1">
                <div className="mb-6">
                  <span className="text-4xl font-bold">€{plan.price[billingInterval]}</span>
                  <span className="text-muted-foreground ml-2">
                    {plan.price[billingInterval] === "0" ? "" : `/${billingInterval === "monthly" ? "mes" : "año"}`}
                  </span>
                </div>
                
                <ul className="space-y-3">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start">
                      <Check className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              
              <CardFooter>
                <Button 
                  className={`w-full ${plan.isPopular ? "bg-blue-600 hover:bg-blue-700" : ""}`}
                  onClick={() => handlePlanSelect(plan.name)}
                >
                  {plan.buttonText}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
        
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">¿Tienes alguna duda?</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-6">
            Nuestro equipo está disponible para ayudarte a elegir el plan más adecuado
            para tus necesidades específicas.
          </p>
          <Button variant="outline" size="lg" onClick={() => window.alert("Esta funcionalidad no está implementada en esta demo.")}>
            Contactar con ventas
          </Button>
        </div>
      </div>
    </div>
  );
}