import { Outlet } from "react-router-dom";
import { Navbar } from "./navbar";
import { Toaster } from "@/components/ui/sonner";

export function MainLayout() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <Outlet />
      </main>
      <Toaster />
    </div>
  );
}