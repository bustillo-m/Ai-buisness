// Tipos para la aplicación
export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
}

export interface User {
  id: string;
  email: string;
  apiKey?: string;
}

export type AuthStatus = 'authenticated' | 'unauthenticated' | 'loading';